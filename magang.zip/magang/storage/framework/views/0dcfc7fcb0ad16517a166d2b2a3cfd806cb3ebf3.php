<!DOCTYPE html>
<html>
<head>
<title>Inovasi</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 5px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #0d6efd;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media  screen and (max-width: 650px) {
  .column {
    width: 80%;
    display: block;
  }
}
  .top_bar_left{
    background-color: #0b7698;
  }
</style>
</head>
<body>

<div class="about-section top_bar_left">
  <h1>About Us</h1>
  <p>Tim Pengurus LPPM-UMN.</p>
  <p>Resize the browser window to see that this page is responsive by the way.</p>
</div>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index">Home</a>
      </li>
      <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle active" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Profile
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="about">About</a></li>
            <li><a class="dropdown-item" href="#">Organisasi</a></li>
            <li><a class="dropdown-item" href="#">Directory</a></li>
          </ul>
          </li>
        </ul>
      </div>
      <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            HKI
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="hki">Hak Cipta</a></li>
            <li><a class="dropdown-item" href="#">Patent</a></li>
            <li><a class="dropdown-item" href="#">Hak merk</a></li>
            <li><a class="dropdown-item" href="about">Hak Rahasia Dagang</a></li>
            <li><a class="dropdown-item" href="#">Desain industri</a></li>
            <li><a class="dropdown-item" href="#">tata letak</a></li>
          </ul>
          </li>
        </ul>
      </div>
      <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Kerjasama
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="university">University</a></li>
            <li><a class="dropdown-item" href="#">Government</a></li>
            <li><a class="dropdown-item" href="#">Industry</a></li>
          </li>
        </ul>
      </div>
      <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Servis
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="#">Seminar</a></li>
            <li><a class="dropdown-item" href="#">Conference</a></li>
            <li><a class="dropdown-item" href="#">Call of paper</a></li>
            <li><a class="dropdown-item" href="#">Alih teknologi inovasi</a></li>
            <li><a class="dropdown-item" href="#">Inkubasi start-up</a></li>
          </li>
        </ul>
      </div>
      <li class="nav-item">
        <a class="nav-link" href="login">Sign in</a>
      </li>

    </ul>
  </div>
</nav>

<div class="bg-light py-5">
  <div class="container py-5">
    <div class="row mb-4">
      <div class="col-lg-5">
        <h2 class="display-4 font-weight-light">Our team</h2>
        <p class="font-italic text-muted">Tim Pengurus LPPM-UMN.</p>
      </div>
    </div>

    <div class="row text-center">
      <?php $__currentLoopData = $dosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <!-- Team item-->
      <div class="col-xl-3 col-sm-6 mb-5">
        <div class="bg-white rounded shadow-sm py-5 px-4"><img src="<?php echo e($data->foto); ?>" alt="" width="100" class="img-fluid rounded-circle mb-3 img-thumbnail shadow-sm">
        <div class="vc_btn3-container vc_btn3-inline vc_custom_1639624503969">
          <a onmouseleave="this.style.borderColor='#666666'; this.style.backgroundColor='transparent'; this.style.color='#666666'" onmouseenter="this.style.borderColor='#666666'; this.style.backgroundColor='#666666'; this.style.color='#ffffff';" 
          style="border-color: rgb(102, 102, 102); color: rgb(102, 102, 102); background-color: transparent;" class="vc_general vc_btn3 vc_btn3-size-md vc_btn3-shape-square vc_btn3-style-outline-custom vc_btn3-icon-right" a="" 
          href="detail/<?php echo e($data->id); ?>" title="View Details">View Details <i class="vc_btn3-icon fas fa-arrow-right"></i></a></div>
          <h5 class="mb-0"><?php echo e($data->nama); ?> </h5><span class="small text-uppercase text-muted"><?php echo e($data->gelar); ?></span>
        </div>
      </div>
      <!-- End-->
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </div>
</div>
<div class="bg-light py-5">
  <div class="container py-5">
    <div class="row mb-4">
      <div class="col-lg-5">
        <h2 class="display-4 font-weight-light">Our team</h2>
        <p class="font-italic text-muted">Tim Pengurus LPPM-UMN.</p>
      </div>
    </div>
    <img src="https://drive.google.com/uc?export=view&id=1dksvYAiO55Xp3MMRUsfb4Jei7gpM1V_Z" alt="Girl in a jacket">


<footer class="bg-light pb-5">
  <div class="container text-center">
    <p class="font-italic text-muted mb-0">&copy; Copyrights Company.com All rights reserved.</p>
  </div>
</footer>



</body>
</html>
<?php /**PATH D:\DANANG\magang\magang\resources\views/about.blade.php ENDPATH**/ ?>