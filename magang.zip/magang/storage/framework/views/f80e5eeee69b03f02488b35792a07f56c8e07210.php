<!DOCTYPE html>
<html lang="en">
<head>
  <title>Inovasi</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
  <style>
  .fakeimg {
    height: 200px;
    background: #aaa;
  }
  </style>
</head>
<body>
<div class="p-5 bg-primary text-white text-center">
  <h1>INOVASI</h1>
  <p>Research, Inovations, Community, and Outreach System Universitas Multimedia Nusantara</p> 
</div>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link active" href="#">Home</a>
      </li>
      <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Profile
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="about">About</a></li>
            <li><a class="dropdown-item" href="#">Organisasi</a></li>
            <li><a class="dropdown-item" href="#">Directory</a></li>
          </ul>
          </li>
        </ul>
      </div>
      <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            HKI
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="hki">Hak Cipta</a></li>
            <li><a class="dropdown-item" href="#">Patent</a></li>
            <li><a class="dropdown-item" href="#">Hak merk</a></li>
            <li><a class="dropdown-item" href="about">Hak Rahasia Dagang</a></li>
            <li><a class="dropdown-item" href="#">Desain industri</a></li>
            <li><a class="dropdown-item" href="#">tata letak</a></li>
          </ul>
          </li>
        </ul>
      </div>
      <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Kerjasama
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="university">University</a></li>
            <li><a class="dropdown-item" href="#">Government</a></li>
            <li><a class="dropdown-item" href="#">Industry</a></li>
          </li>
        </ul>
      </div>
      <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Servis
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="#">Seminar</a></li>
            <li><a class="dropdown-item" href="#">Conference</a></li>
            <li><a class="dropdown-item" href="#">Call of paper</a></li>
            <li><a class="dropdown-item" href="#">Alih teknologi inovasi</a></li>
            <li><a class="dropdown-item" href="#">Inkubasi start-up</a></li>
          </li>
        </ul>
      </div>
      <li class="nav-item">
        <a class="nav-link" href="login">Sign in</a>
      </li>

    </ul>
  </div>
</nav>

<div class="container mt-5">
  <div class="row">
    <div class="col-sm-4 bg-dark text-white">
      
      <h2>Profile</h2>
      <p>Visi : Universitas Multimedia Nusantara menjadi perguruan tinggi unggulan di bidang ICT, baik di tingkat nasional maupun 
        internasional, yang menghasilkan lulusan berwawasan internasional dan berkompetensi tinggi di bidangnya (berkeahlian) 
        yang disertai jiwa wirausaha serta berbudi pekerti luhur. 
      </p>
      <p>Misi : Turut serta mencerdaskan kehidupan bangsa dan memajukan kesejahteraan bangsa 
        melalui upaya penyelenggaraan pendidikan tinggi dengan melaksanakan Tridarma Perguruan 
        Tinggi (Pendidikan, Penelitian dan Pengabdian pada Masyarakat), untuk meningkatkan kualitas sumber 
        daya manusia Indonesia.</p>
      
      <h3 class="mt-4">Contact Us</h3>
      <p>Universitas Multimedia Nusantara Jl. Scientia Boulevard, 
        Gading Serpong, Tangerang, Banten - 15811 Indonesia</p>
      <p>(t) +62-21. 5422.0808; (f) +62-21. 5422.0800;</p>
      <p>Email : marketing@umn.ac.id</p>
      <p>Facebook : marketing.umn</p>
      <p>Twitter : umn_serpong</p>
      
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>News 1</h2>
      <h5>Mahasiswa Arsitektur UMN Ciptakan Produk Inovasi Untuk Hadapi COVID-19.</h5>
      <p>July, 30 2020</p>
      <img src="https://www2.umn.ac.id/wp-content/uploads/2020/06/SLIDER-8.jpg" width="750" height="500">
      <p>Produk Inovasi Masa Pandemi Covid-19 oleh Mahasiswa Arsitektur UMN (dok. UMN)</p>
      <p>TANGERANG – Mahasiswa Program Studi Arsitektur UMN merancang desain produk sebagai solusi menghadapi pandemi COVID-19 pada Ujian Akhir Semester (UAS) Genap 2019-2020 untuk mata kuliah Digital Fabrication. 
      Tak hanya desain, Dosen mata kuliah Digital Fabrication, Rizki Tridamayanti Siregar memamparkan bahwa terdapat hasil akhir berupa prototipe (produk awal) untuk desain berskala kecil ataupun maket (miniatur tiga dimensi) untuk desain berskala besar...</p>

      <h2>News 2</h2>
      <h5 class="entry-title" itemprop="headline">
        <a href="https://www.umn.ac.id/en/tiga-ide-bisnis-mahasiswa-mmt-umn-borong-silver-award-di-ajang-kompetisi-internasional-2/"> 
        Three Business Ideas MMT UMN Students get many Silver Awards in International Competitions</a>
      </h5>
      <p>October, 6 2021</p>
      <img src="https://www.umn.ac.id/wp-content/uploads/2021/10/Tiga-ide-bisnis-mahasiswa-MMT-UMN-sabet-Silver-Award-di-ajang-kompetisi-International-Business-and-Management-Virtual-Innovation-and-Invention-of-Ideas-Competition-VIIIC-2021.jpeg" width="750" height="500">
      <p>Three business ideas from MMT UMN’s students won the Silver Award at the “International Business and Management Virtual Innovation and Invention of Ideas Competition (VIIIC) 2021” competition.</p>
      <p>TANGERANG – Three innovative ideas of students of the Technology Management Magister Study Program of Multimedia Nusantara University 
      (MMT UMN) earned Silver Award in an international competition entitled “International Business and Management Virtual Innovation and Invention of Ideas Competition (VIIIC) 2021” 
      held on Thursday (30/09/21). As many as 85 teams from the Southeast Asia countries took part in the Competition was organized by MARA University of Technology, Malaysia....</p>

      <h2>News 3</h2>
      <h5>Mahasiswa UMN Lolos Kompetisi Inovasi Bisnis Mahasiswa Indonesia</h5>
      <p>October, 20 2020</p>
      <img src="https://www.umn.ac.id/wp-content/uploads/2020/10/HEADLINE-BLOG-WEB-UMN-1536x864.png" width="750" height="500">
      <p>Tim Take and Gift. (dok.UMN)</p>
      <p>TANGERANG – Linda Febriana Purwanto (DKV 2018), Eunike Anastasia Iskandar (DKV 2018), dan Ronaldo Oetomo (Manajemen 2018) kembali memberikan catatan prestasi dengan berhasil lolos Kompetisi Inovasi Bisnis Mahasiswa (KIBM) 2020. Tim yang mengusung ide dengan judul “Take and Gift” 
      ini lolos dalam kompetisi tahunan yang diselenggarakan oleh Pusat Prestasi Nasional, Kementerian Pendidikan dan Kebudayaan Republik Indonesia sebagai dorongan lahirnya wirausahawan kreatif dan inovatif di era industri 4.0....</p>
    </div>
  </div>
</div>

<div class="mt-5 p-4 bg-dark text-white text-center">
  <p>Footer</p>
</div>

</body>
</html>
<?php /**PATH D:\DANANG\magang\magang\resources\views/welcome.blade.php ENDPATH**/ ?>