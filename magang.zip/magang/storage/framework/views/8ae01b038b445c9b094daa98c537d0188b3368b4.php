<!DOCTYPE html>
<html>
<head>
<title>Inovasi</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 5px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #0d6efd;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media  screen and (max-width: 650px) {
  .column {
    width: 80%;
    display: block;
  }
}
</style>
</head>
<body>

<div class="about-section ">
  <h1>About Us</h1>
  <p>Tim Pengurus LPPM-UMN.</p>
  <p>Resize the browser window to see that this page is responsive by the way.</p>
</div>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link active" href="#">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Profile</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">HKI</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Kerjasama</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Servis</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Cari data</a>
      </li>
    </ul>
  </div>
</nav>

<h2 style="text-align:center">Pengurus LPPM</h2>
<div class="row">
  <div class="column">
    <div class="card">
      <img src="https://www.umn.ac.id/wp-content/uploads/2020/10/Pak-winarno.jpg" alt="Winarno" style="margin:5px">
      <div class="container">
        <h2>Dr.Ir.Winarno,S.Kom.</h2>
        <p class="title">Direktur LPPM</p>
        <p>Some text that describes me lorem ipsum ipsum lorem.</p>
        <p>jane@example.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="https://www.umn.ac.id/wp-content/uploads/2020/10/Ibu-Friska.jpg" alt="Frisca" style="margin:5px;">
      <div class="container">
        <h2>Friska Natalia Ph.D</h2>
        <p class="title">Head of Research Center UMN</p>
        <p>Some text that describes me lorem ipsum ipsum lorem.</p>
        <p>Email :friska.natalia@umn.ac.id</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
  
  <div class="column">
    <div class="card">
      <img src="/w3images/team3.jpg" alt="John" style="width:100%">
      <div class="container">
        <h2>John Doe</h2>
        <p class="title">Designer</p>
        <p>Some text that describes me lorem ipsum ipsum lorem.</p>
        <p>john@example.com</p>
        <p><button class="button">Contact</button></p>
      </div>
    </div>
  </div>
</div>

</body>
</html>
<?php /**PATH D:\DANANG\magang\magang\resources\views/aboutus.blade.php ENDPATH**/ ?>