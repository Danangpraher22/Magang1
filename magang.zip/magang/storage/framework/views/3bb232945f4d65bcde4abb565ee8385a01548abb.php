<!DOCTYPE html>
<html>
<head>
<title>Inovasi</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta charset="utf-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 5px;
}

.about-section {
  padding: 50px;
  text-align: center;
  background-color: #0d6efd;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media  screen and (max-width: 650px) {
  .column {
    width: 80%;
    display: block;
  }
}

.top_bar_left{
    background-color: #0b7698;
  }
</style>
</head>
<body>

<div class="about-section top_bar_left">
  <h1>About Us</h1>
  <p>Tim Pengurus LPPM-UMN.</p>
  <p>Resize the browser window to see that this page is responsive by the way.</p>
</div>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="../index">Home</a>
      </li>
      <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle active" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Profile
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="../about">About</a></li>
            <li><a class="dropdown-item" href="#">Organisasi</a></li>
            <li><a class="dropdown-item" href="#">Directory</a></li>
          </ul>
          </li>
        </ul>
      </div>
      <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            HKI
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="../hki">Hak Cipta</a></li>
            <li><a class="dropdown-item" href="#">Patent</a></li>
            <li><a class="dropdown-item" href="#">Hak merk</a></li>
            <li><a class="dropdown-item" href="about">Hak Rahasia Dagang</a></li>
            <li><a class="dropdown-item" href="#">Desain industri</a></li>
            <li><a class="dropdown-item" href="#">tata letak</a></li>
          </ul>
          </li>
        </ul>
      </div>
      <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Kerjasama
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="#">University</a></li>
            <li><a class="dropdown-item" href="#">Government</a></li>
            <li><a class="dropdown-item" href="#">Industry</a></li>
          </li>
        </ul>
      </div>
      <div class="collapse navbar-collapse" id="navbarNavDarkDropdown">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDarkDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Servis
          </a>
          <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="navbarDarkDropdownMenuLink">
            <li><a class="dropdown-item" href="#">Seminar</a></li>
            <li><a class="dropdown-item" href="#">Conference</a></li>
            <li><a class="dropdown-item" href="#">Call of paper</a></li>
            <li><a class="dropdown-item" href="#">Alih teknologi inovasi</a></li>
            <li><a class="dropdown-item" href="#">Inkubasi start-up</a></li>
          </li>
        </ul>
      </div>
      <li class="nav-item">
        <a class="nav-link" href="login">Sign in</a>
      </li>

    </ul>
  </div>
</nav>
<div class="card" style="max-width: 500px;">
    <div class="row no-gutters">
        <div class="col-md-5">
            <img src="<?php echo e($dosen->foto); ?>" class="card-img-top h-100" alt="...">
        </div>
        <div class="col-md-7">
            <div class="card-body">
                <h5 class="card-title">Nama : <?php echo e($dosen->nama); ?></h5>
                <p class="card-text">Gelar : <?php echo e($dosen->gelar); ?></p>
            </div>
        </div>
    </div>
</div>


<footer class="bg-light pb-5">
  <div class="container text-center">
    <p class="font-italic text-muted mb-0">&copy; Copyrights Company.com All rights reserved.</p>
  </div>
</footer>



</body>
</html>
<?php /**PATH D:\DANANG\magang\magang\resources\views/winarno.blade.php ENDPATH**/ ?>