<!DOCTYPE html>
<html>
<head>
<title>Inovasi</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {margin:0;font-family:Arial}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.active {
  background-color: #04AA6D;
  color: white;
}

.topnav .icon {
  display: none;
}

.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 17px;    
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.topnav a:hover, .dropdown:hover .dropbtn {
  background-color: #555;
  color: white;
}

.dropdown-content a:hover {
  background-color: #ddd;
  color: black;
}

.dropdown:hover .dropdown-content {
  display: block;
}

@media  screen and (max-width: 600px) {
  .topnav a:not(:first-child), .dropdown .dropbtn {
    display: none;
  }
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media  screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
  .topnav.responsive .dropdown {float: none;}
  .topnav.responsive .dropdown-content {position: relative;}
  .topnav.responsive .dropdown .dropbtn {
    display: block;
    width: 100%;
    text-align: left;
  }
}
</style>
</head>
<body>
<div class="p-5 bg-primary text-white text-center">
  <h1>INOVASI</h1>
  <p>Research, Inovations, Community, and Outreach System Universitas Multimedia Nusantara</p> 
</div>

<div class="topnav" id="myTopnav">
  <a href="index" class="active">Home</a>
  <a href="profile">Profile</a>
  <a href="#contact">Contact</a>
  <div class="dropdown">
    <button class="dropbtn">HKI
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Universitas</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div>
  <div class="dropdown">
    <button class="dropbtn">Uni
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="#">Universitas</a>
      <a href="#">Link 2</a>
      <a href="#">Link 3</a>
    </div>
  </div>
  <a href="#about">About</a>
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
</div>

<div class="container mt-5">
  <div class="row">
    <div class="col-sm-4 bg-dark text-white">
      
      <h2>Profile</h2>
      <p>Visi : Universitas Multimedia Nusantara menjadi perguruan tinggi unggulan di bidang ICT, baik di tingkat nasional maupun 
        internasional, yang menghasilkan lulusan berwawasan internasional dan berkompetensi tinggi di bidangnya (berkeahlian) 
        yang disertai jiwa wirausaha serta berbudi pekerti luhur. 
      </p>
      <p>Misi : Turut serta mencerdaskan kehidupan bangsa dan memajukan kesejahteraan bangsa 
        melalui upaya penyelenggaraan pendidikan tinggi dengan melaksanakan Tridarma Perguruan 
        Tinggi (Pendidikan, Penelitian dan Pengabdian pada Masyarakat), untuk meningkatkan kualitas sumber 
        daya manusia Indonesia.</p>
      
      <h3 class="mt-4">Contact Us</h3>
      <p>Universitas Multimedia Nusantara Jl. Scientia Boulevard, 
        Gading Serpong, Tangerang, Banten - 15811 Indonesia</p>
      <p>(t) +62-21. 5422.0808; (f) +62-21. 5422.0800;</p>
      <p>Email : marketing@umn.ac.id</p>
      <p>Facebook : marketing.umn</p>
      <p>Twitter : umn_serpong</p>
      
      <hr class="d-sm-none">
    </div>
    <div class="col-sm-8">
      <h2>News 1</h2>
      <h5>Anti hoax, Dec 7, 2020</h5>
      <img src="https://asset.kompas.com/crops/j7-t_cIY1yC4tZ59enOLqxr4FPc=/387x0:5004x3078/750x500/data/photo/2020/09/18/5f644a893ef9e.jpg" width="750" height="500">
      <p>Some text..</p>
      <p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>

      <h2 class="mt-5">News 2</h2>
      <h5>Title description, Sep 2, 2020</h5>
      <div class="fakeimg">Fake Image</div>
      <p>Some text..</p>
      <p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>

      <h2 class="mt-5">News 3</h2>
      <h5>Title description, Sep 2, 2020</h5>
      <div class="fakeimg">Fake Image</div>
      <p>Some text..</p>
      <p>Sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
    </div>
  </div>
</div>

<div class="mt-5 p-4 bg-dark text-white text-center">
  <p>Footer</p>
</div>

<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

</body>
</html>
<?php /**PATH D:\DANANG\magang\magang\resources\views/navbar.blade.php ENDPATH**/ ?>