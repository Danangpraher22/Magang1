<?php

namespace App\Http\Controllers;

use App\Models\industry;
use Illuminate\Http\Request;

class IndustryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\industry  $industry
     * @return \Illuminate\Http\Response
     */
    public function show(industry $industry)
    {
        $data = $industry->get();
        return view('industry', ['industries' => $data]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\industry  $industry
     * @return \Illuminate\Http\Response
     */
    public function edit(industry $industry)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\industry  $industry
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, industry $industry)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\industry  $industry
     * @return \Illuminate\Http\Response
     */
    public function destroy(industry $industry)
    {
        //
    }
}
