<?php

namespace App\Http\Controllers;

use App\Models\universitas;
use Illuminate\Http\Request;

class UniversitasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\universitas  $universitas
     * @return \Illuminate\Http\Response
     */
    public function show(universitas $universitas)
    {
        $data = $universitas->get();
        return view('university', ['universitas' => $data]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\universitas  $universitas
     * @return \Illuminate\Http\Response
     */
    public function edit(universitas $universitas)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\universitas  $universitas
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, universitas $universitas)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\universitas  $universitas
     * @return \Illuminate\Http\Response
     */
    public function destroy(universitas $universitas)
    {
        //
    }
}
