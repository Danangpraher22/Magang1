<?php

namespace App\Http\Controllers;

use App\Models\Hakcipta;
use Illuminate\Http\Request;

class HakciptaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Hakcipta  $hakcipta
     * @return \Illuminate\Http\Response
     */
    public function show(Hakcipta $hakcipta)
    {
        $data = $hakcipta->get();
        return view('hki', ['hakcipta' => $data]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Hakcipta  $hakcipta
     * @return \Illuminate\Http\Response
     */
    public function edit(Hakcipta $hakcipta)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Hakcipta  $hakcipta
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Hakcipta $hakcipta)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Hakcipta  $hakcipta
     * @return \Illuminate\Http\Response
     */
    public function destroy(Hakcipta $hakcipta, $id)
    {
        $data = Hakcipta::find($id);
        $data->delete();
    }
}
