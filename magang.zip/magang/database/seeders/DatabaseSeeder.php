<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Hakcipta;
use App\Models\universitas;
use App\Models\pemerintah;
use App\Models\industry;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $hakcipta = new Hakcipta(["tahun"=> "2016", "penulis" => "Felix Adrianto, Yustinus Eko Soelistio, S.Kom., M.M. ", "judul" => "Program Komputer Sistem FAAS (FACIAL-BASED SECURITY SYSTEM)", "hki" => "086116", "pendaftaran" => "C00201700812"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2016", "penulis" => "Annita, S.Pd., MFA.", "judul" => "Video Elearning Pembelajaran Film dan Prosedur", "hki" => "089340", "pendaftaran" => "C00201704162"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2016", "penulis" => "Bharoto Yekti, S.Ds., M.A.", "judul" => "Karakter 'Robo-Cross'", "hki" => "089341", "pendaftaran" => "C00201704163"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2016", "penulis" => "Makbul Mubarak, S.IP., M.A.", "judul" => "Film Pendek 'Wabah'", "hki" => "089342", "pendaftaran" => "C00201704164"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2016", "penulis" => "Makbul Mubarak, S.IP., M.A.", "judul" => "Film Pendek 'Sugih'", "hki" => "089343", "pendaftaran" => "C00201704165"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2015", "penulis" => "Ranny", "judul" => "Rancangan Buku Ajar Untuk Bahasa Pemprograman Berorientasi Objek", "hki" => "077795", "pendaftaran" => "C00201504652"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2015", "penulis" => "Maria Irmina Prasetiyowati, S.Kom., M.T.", "judul" => "Teknik Merancang Program", "hki" => "077796", "pendaftaran" => "C00201504653"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Hira Meidia, B.Eng., Ph.D.", "judul" => "Microanalysis Of State of The Art Nanoscale Ceramic  ", "hki" => "055163", "pendaftaran" => "C00201003721"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2011", "penulis" => "Yusup Sigit Martyastiadi, S.T., M.Inf.Tech.", "judul" => "Karakter Blegug", "hki" => "057296", "pendaftaran" => "C00201101479"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2011", "penulis" => "Yusup Sigit Martyastiadi, S.T., M.Inf.Tech.", "judul" => "Karakter Geyong", "hki" => "057297", "pendaftaran" => "C00201101480"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2011", "penulis" => "Ratna Cahaya Rina, M.Ds.", "judul" => "Skenario Film Panjang 'Salah'", "hki" => "057298", "pendaftaran" => "C00201101481"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2011", "penulis" => "Desi Dwi Kristiawan", "judul" => "Video Tutorial- Mouse Modeling", "hki" => "057299", "pendaftaran" => "C00201101482"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Maria Irmina Prasetiyowati, S.Kom., M.T.", "judul" => "Modul Praktikum 'Pengantar Teknologi Multimedia'", "hki" => "052958", "pendaftaran" => "C00201001630"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Maria Irmina Prasetiyowati, S.Kom., M.T.", "judul" => "Modul Praktikum 2 'Pengantar Teknologi Multimedia'", "hki" => "052959", "pendaftaran" => "C00201001631"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Dr. Winarno, M.Kom.", "judul" => "Budaya Perusahaan Yang Membangun Sikap Intrapreneurship Karyawan", "hki" => "052960", "pendaftaran" => "C00201001632"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Rosita Suryaningsih, S.E., M.M.", "judul" => "Anggaran (Budgetting)", "hki" => "052964", "pendaftaran" => "C00201001636"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Rosita Suryaningsih, S.E., M.M.", "judul" => "Break Even Point (BEP)", "hki" => "052965", "pendaftaran" => "C00201001637"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Dra. Ratnawati Kurnia, AK., M.Si.CPA", "judul" => "Karya Tulis management Control System", "hki" => "", "pendaftaran" => "C00201001625"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Dra. Ratnawati Kurnia, AK., M.Si.CPA", "judul" => "Karya Tulis  Laporan Keuangan (Financial Report", "hki" => "", "pendaftaran" => "C00201001626"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Edwin Hartono, S.Sn., M.A.", "judul" => "Film Animasi/ Launching UMN", "hki" => "058229", "pendaftaran" => "C00201002094"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Niknik Mediyawati, S.Pd., M.Hum.", "judul" => "Kesantunan Penggunaan Bahasa Indonesia dalam kegiatan administrasi Kampus", "hki" => "052946", "pendaftaran" => "C00201001618"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Niknik Mediyawati, S.Pd., M.Hum.", "judul" => "Bahasa Indonesia sebagai mata kuliah kepribadian", "hki" => "052947", "pendaftaran" => "C00201001619"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Ambang Priyonggo R. SS., M.A", "judul" => "Teknik Penulisan Berita Media Cetak", "hki" => "052948", "pendaftaran" => "C00201001620"]); $hakcipta->save();
$hakcipta = new Hakcipta(["tahun"=> "2010", "penulis" => "Dr. Bherta Sri Eko M., M.Si.", "judul" => "Pengantar Ilmu Komunikasi", "hki" => "052952", "pendaftaran" => "C00201001624"]); $hakcipta->save();

        
        
        
    }
}
