<?php

use App\Http\Controllers\DosenController;
use App\Http\Controllers\HakciptaController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UniversitasController;
use App\Http\Controllers\IndustryController;
use App\Http\Controllers\PemerintahController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('index', function () {
    return view('index');
});

Route::get('login', function () {
    return view('login');
});

Route::get('about', [DosenController::class, 'index']);

Route::get('profile', function () {
    return view('profile');
});
Route::get('admin', function () {
    return view('admin');
});
Route::get('hki', [HakciptaController::class, 'show']);
Route::get('hki/delete/{id}', [HakciptaController::class, 'destroy']);

Route::get('navbar', function () {
    return view('navbar');
});

Route::get('detail/{id}', [DosenController::class, 'show']);

Route::get('data',[HakciptaController::class, 'show']);

Route::get('university',[UniversitasController::class, 'show']);

Route::get('government',[PemerintahController::class, 'show']);

Route::get('industry',[IndustryController::class, 'show']);

